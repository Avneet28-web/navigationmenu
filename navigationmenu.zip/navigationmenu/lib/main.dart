import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, // Removes the debug banner
      title: 'City Explorer',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const SplashScreen(),
    );
  }
}

// Splash Screen
class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const HomePage()),
      );
    });

    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Image.asset(
          'assets/logo.jpg', // Path to your logo
          width: 300, // Adjust logo size
          height: 300,
          fit: BoxFit.contain,
          errorBuilder: (context, error, stackTrace) {
            return const Icon(
              Icons.broken_image,
              size: 200,
              color: Colors.grey,
            );
          },
        ),
      ),
    );
  }
}

// Home Page
class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    // Centralized list of cities
    final List<Map<String, String>> cities = [
      {
        'name': 'Toronto',
        'image': 'assets/toronto.jpg',
        'description': 'Toronto is the largest city in Canada, known for the CN Tower and its diverse culture.',
      },
      {
        'name': 'Vancouver',
        'image': 'assets/vancouver.jpg',
        'description': 'Vancouver is a coastal city in British Columbia, famous for its mountains and waterfronts.',
      },
      {
        'name': 'Montreal',
        'image': 'assets/montreal.jpg',
        'description': 'Montreal is a vibrant city in Quebec, known for its French influence and rich history.',
      },
      {
        'name': 'Paris',
        'image': 'assets/paris.jpg',
        'description': 'Paris, the capital of France, is famous for the Eiffel Tower and its romantic ambiance.',
      },
      {
        'name': 'Tokyo',
        'image': 'assets/tokyo.jpg',
        'description': 'Tokyo, Japan\'s bustling capital, is known for its skyscrapers, technology, and cherry blossoms.',
      },
      {
        'name': 'New York',
        'image': 'assets/new_york.jpg',
        'description': 'New York City, USA, is the city that never sleeps, home to Times Square and Central Park.',
      },
      {
        'name': 'Sydney',
        'image': 'assets/sydney.jpg',
        'description': 'Sydney, Australia, is famous for the Sydney Opera House and its beautiful harbor.',
      },
      {
        'name': 'Barcelona',
        'image': 'assets/barcelona.jpg',
        'description': 'Barcelona, Spain, is known for its art, architecture, and vibrant beaches.',
      },
      {
        'name': 'Rio de Janeiro',
        'image': 'assets/rio.jpg',
        'description': 'Rio de Janeiro, Brazil, is famous for its Carnival festival and Christ the Redeemer statue.',
      },
      {
        'name': 'Venice',
        'image': 'assets/venice.jpg',
        'description': 'Venice, Italy, is renowned for its canals, gondolas, and historic landmarks.',
      },
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('City Explorer'),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
              child: Text(
                'Navigate to City',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                ),
              ),
            ),
            for (var city in cities)
              ListTile(
                leading: const Icon(Icons.location_city),
                title: Text(city['name']!),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => CityPage(
                        cityName: city['name']!,
                        cityImage: city['image']!,
                        cityDescription: city['description']!,
                      ),
                    ),
                  );
                },
              ),
          ],
        ),
      ),
      body: const Center(
        child: Text(
          'Welcome to City Explorer!',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}

// City Page
class CityPage extends StatelessWidget {
  final String cityName;
  final String cityImage;
  final String cityDescription;

  const CityPage({
    super.key,
    required this.cityName,
    required this.cityImage,
    required this.cityDescription,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(cityName),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Image.asset(
              cityImage,
              height: 250,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return const Icon(
                  Icons.broken_image,
                  size: 250,
                  color: Colors.grey,
                );
              },
            ),
            const SizedBox(height: 20),
            Text(
              cityName,
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Text(
              cityDescription,
              style: const TextStyle(fontSize: 18),
            ),
          ],
        ),
      ),
    );
  }
}
