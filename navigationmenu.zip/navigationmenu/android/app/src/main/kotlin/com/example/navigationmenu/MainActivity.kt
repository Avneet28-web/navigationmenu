package com.example.navigationmenu

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
